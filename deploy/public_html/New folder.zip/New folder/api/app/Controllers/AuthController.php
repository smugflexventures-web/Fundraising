<?php

namespace App\Controllers;

use App\Models\User;
use App\Models\PasswordReset;
use App\Helpers\JWT;
use App\Helpers\Validator;
use App\Helpers\Mailer;
use App\Helpers\Helpers;
use App\Core\Response;
use App\Core\Database;

class AuthController
{
    private $userModel;

    public function __construct()
    {
        $this->userModel = new User();
    }

    public function register($params)
    {
        $input = json_decode(file_get_contents('php://input'), true) ?? [];
        $input = Helpers::sanitize($input);

        $validator = new Validator($input);
        $validator->validate([
            'first_name' => 'required|alpha_spaces|min:2|max:50',
            'last_name' => 'required|alpha_spaces|min:2|max:50',
            'email' => 'required|email',
            'password' => 'required|password',
            'confirm_password' => 'required|same:password',
            'role' => 'required|in:student,donor',
        ]);

        if ($validator->fails()) {
            return Response::error('Validation failed', 422, $validator->getErrors());
        }

        $existingUser = $this->userModel->findByEmail($input['email']);
        if ($existingUser) {
            return Response::error('Email already registered', 409);
        }

        if ($input['role'] === 'student') {
            if (empty($input['student_id'])) {
                return Response::error('Student ID is required for student registration', 422);
            }
            $existingStudent = $this->userModel->findByStudentId($input['student_id']);
            if ($existingStudent) {
                return Response::error('Student ID already registered', 409);
            }
        }

        $userData = [
            'email' => $input['email'],
            'password' => $input['password'],
            'first_name' => $input['first_name'],
            'last_name' => $input['last_name'],
            'phone' => $input['phone'] ?? null,
            'role' => $input['role'],
            'student_id' => $input['student_id'] ?? null,
            'department' => $input['department'] ?? null,
            'level' => $input['level'] ?? null,
        ];

        $userId = $this->userModel->create($userData);

        if (!$userId) {
            return Response::error('Registration failed', 500);
        }

        $user = $this->userModel->findById($userId);
        $token = JWT::generate([
            'user_id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role'],
        ]);

        Helpers::createNotification($userId, 'Welcome to CampusFund', 'Your account has been created successfully. Welcome aboard!', 'success');
        Helpers::logActivity($userId, 'register', 'User registered', $_SERVER['REMOTE_ADDR'] ?? null, $_SERVER['HTTP_USER_AGENT'] ?? null);

        Mailer::sendWelcomeEmail($user['email'], $user['first_name']);

        unset($user['password']);

        return Response::success([
            'user' => $user,
            'token' => $token,
        ], 'Registration successful', 201);
    }

    public function login($params)
    {
        $input = json_decode(file_get_contents('php://input'), true) ?? [];
        $input = Helpers::sanitize($input);

        $validator = new Validator($input);
        $validator->validate([
            'email' => 'required|email',
            'password' => 'required',
        ]);

        if ($validator->fails()) {
            return Response::error('Validation failed', 422, $validator->getErrors());
        }

        $user = $this->userModel->verifyPassword($input['email'], $input['password']);

        if (!$user) {
            return Response::error('Invalid email or password', 401);
        }

        if (!$user['is_active']) {
            return Response::error('Account is deactivated. Contact administrator.', 403);
        }

        $this->userModel->updateLastLogin($user['id']);

        $token = JWT::generate([
            'user_id' => $user['id'],
            'email' => $user['email'],
            'role' => $user['role'],
        ]);

        unset($user['password']);

        Helpers::logActivity($user['id'], 'login', 'User logged in', $_SERVER['REMOTE_ADDR'] ?? null, $_SERVER['HTTP_USER_AGENT'] ?? null);

        return Response::success([
            'user' => $user,
            'token' => $token,
        ], 'Login successful');
    }

    public function logout($params)
    {
        $authUser = $GLOBALS['auth_user'] ?? null;
        if ($authUser) {
            Helpers::logActivity($authUser['user_id'], 'logout', 'User logged out');
        }
        return Response::success([], 'Logged out successfully');
    }

    public function forgotPassword($params)
    {
        $input = json_decode(file_get_contents('php://input'), true) ?? [];
        $input = Helpers::sanitize($input);

        $validator = new Validator($input);
        $validator->validate([
            'email' => 'required|email',
        ]);

        if ($validator->fails()) {
            return Response::error('Validation failed', 422, $validator->getErrors());
        }

        $user = $this->userModel->findByEmail($input['email']);
        if (!$user) {
            return Response::success([], 'If the email exists, a reset link has been sent');
        }

        $token = bin2hex(random_bytes(32));
        $passwordReset = new PasswordReset();
        $passwordReset->create($input['email'], $token);

        $resetLink = (\App\Core\Config::get('APP_URL', 'http://localhost:5173')) . '/reset-password?token=' . $token;

        Mailer::sendPasswordResetEmail($user['email'], $user['first_name'], $resetLink);

        Helpers::logActivity($user['id'], 'forgot_password', 'Password reset requested');

        return Response::success([], 'If the email exists, a reset link has been sent');
    }

    public function resetPassword($params)
    {
        $input = json_decode(file_get_contents('php://input'), true) ?? [];

        $validator = new Validator($input);
        $validator->validate([
            'token' => 'required',
            'password' => 'required|password',
            'confirm_password' => 'required|same:password',
        ]);

        if ($validator->fails()) {
            return Response::error('Validation failed', 422, $validator->getErrors());
        }

        $passwordReset = new PasswordReset();
        $reset = $passwordReset->findByToken($input['token']);

        if (!$reset) {
            return Response::error('Invalid or expired reset token', 400);
        }

        $user = $this->userModel->findByEmail($reset['email']);
        if (!$user) {
            return Response::error('User not found', 404);
        }

        $this->userModel->updatePassword($user['id'], $input['password']);
        $passwordReset->deleteByEmail($reset['email']);

        Helpers::logActivity($user['id'], 'reset_password', 'Password reset successful');
        Helpers::createNotification($user['id'], 'Password Updated', 'Your password has been reset successfully.', 'success');

        return Response::success([], 'Password reset successful');
    }

    public function me($params)
    {
        $authUser = $GLOBALS['auth_user'] ?? null;
        if (!$authUser) {
            return Response::unauthorized();
        }

        $user = $this->userModel->findById($authUser['user_id']);
        if (!$user) {
            return Response::notFound('User not found');
        }

        return Response::success(['user' => $user]);
    }

    public function updateProfile($params)
    {
        $authUser = $GLOBALS['auth_user'] ?? null;
        $input = json_decode(file_get_contents('php://input'), true) ?? [];
        $input = Helpers::sanitize($input);

        $validator = new Validator($input);
        $validator->validate([
            'first_name' => 'required|alpha_spaces|min:2',
            'last_name' => 'required|alpha_spaces|min:2',
        ]);

        if ($validator->fails()) {
            return Response::error('Validation failed', 422, $validator->getErrors());
        }

        $this->userModel->update($authUser['user_id'], $input);
        $user = $this->userModel->findById($authUser['user_id']);

        Helpers::logActivity($authUser['user_id'], 'update_profile', 'Profile updated');

        return Response::success(['user' => $user], 'Profile updated successfully');
    }

    public function changePassword($params)
    {
        $authUser = $GLOBALS['auth_user'] ?? null;
        $input = json_decode(file_get_contents('php://input'), true) ?? [];

        $validator = new Validator($input);
        $validator->validate([
            'current_password' => 'required',
            'new_password' => 'required|password',
            'confirm_password' => 'required|same:new_password',
        ]);

        if ($validator->fails()) {
            return Response::error('Validation failed', 422, $validator->getErrors());
        }

        $user = $this->userModel->findByEmail($authUser['email']);
        if (!password_verify($input['current_password'], $user['password'])) {
            return Response::error('Current password is incorrect', 400);
        }

        $this->userModel->updatePassword($authUser['user_id'], $input['new_password']);
        Helpers::logActivity($authUser['user_id'], 'change_password', 'Password changed');

        return Response::success([], 'Password changed successfully');
    }
}
